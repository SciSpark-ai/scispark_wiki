# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: chat-markdown.spec.ts >> Sparky formats streamed and saved Markdown in the paper popup and full chat
- Location: e2e/chat-markdown.spec.ts:3:5

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByRole('dialog', { name: 'Chat with Sparky' }).locator('[data-streaming-text]').locator('strong')
Expected: "CNNT"
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toHaveText" with timeout 10000ms
  - waiting for getByRole('dialog', { name: 'Chat with Sparky' }).locator('[data-streaming-text]').locator('strong')

```

```yaml
- alert
- complementary:
  - button "Close sidebar"
  - img "SciSpark"
  - button "Switch to dark mode"
  - navigation:
    - text: Discover
    - link "Home":
      - /url: /
    - link "Sparky":
      - /url: /chat
    - text: Knowledge
    - link "Wiki":
      - /url: /wiki
    - link "Graph":
      - /url: /viz
    - link "Projects":
      - /url: /projects
    - text: Tools
    - link "Tools":
      - /url: /tools
    - link "Trending":
      - /url: /trending
    - link "Idea Spark":
      - /url: /spark
    - separator
    - link "History":
      - /url: /history
  - separator
  - button "Profile menu":
    - text: M
    - paragraph: My profile
    - paragraph: Local profile
- main:
  - link "← Back":
    - /url: /
  - heading "E2E Grounding Paper" [level=1]
  - paragraph: Ada Researcher
  - text: SciSpark Preview · 2026
  - group "Paper actions":
    - button "Saved" [pressed]
    - button "Generate digest"
    - button "Add to knowledge base"
    - button "Read full text"
    - button "More like this"
    - button "Less like this"
    - status
  - article "Paper reading":
    - group:
      - text: Original abstract
      - paragraph: This disposable paper demonstrates grounded project retrieval and recovery.
  - complementary "Paper context":
    - text: Project membership
    - paragraph:
      - text: No projects yet.
      - link "Create one":
        - /url: /projects
- dialog "Chat with Sparky":
  - banner:
    - heading "Sparky" [level=2]
    - link "Open full conversation":
      - /url: /chat/chat_f8ec0e5d-a9b4-4bf1-aadc-04b5ca77537d
    - button "Close Sparky chat"
  - paragraph: This paper
  - paragraph: E2E Grounding Paper
  - text: You
  - paragraph: "STREAMING-FIXTURE MARKDOWN-FIXTURE: Explain CNNT."
  - text: Sparky
  - paragraph: Would you like to discuss this, find papers, or run a research tool?
  - button "Save to knowledge base"
  - contentinfo:
    - textbox "Message Sparky":
      - /placeholder: Ask about this paper…
    - button "Send" [disabled]
- button "Close Sparky chat" [expanded]
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test"
  2  | 
  3  | test("Sparky formats streamed and saved Markdown in the paper popup and full chat", async ({ page }, info) => {
  4  |   await page.setViewportSize({ width: 1440, height: 1000 })
  5  |   await page.goto("/paper/e2e-grounding-paper")
  6  |   await expect(page.getByRole("heading", { name: "E2E Grounding Paper", exact: true })).toBeVisible()
  7  |   await page.getByRole("button", { name: "Open Sparky chat", exact: true }).click()
  8  |   const panel = page.getByRole("dialog", { name: "Chat with Sparky" })
  9  |   await panel.getByLabel("Message Sparky").fill("STREAMING-FIXTURE MARKDOWN-FIXTURE: Explain CNNT.")
  10 |   await panel.getByRole("button", { name: "Send", exact: true }).click()
  11 |   const draft = panel.locator("[data-streaming-text]")
> 12 |   await expect(draft.locator("strong")).toHaveText("CNNT")
     |                                         ^ Error: expect(locator).toHaveText(expected) failed
  13 |   expect(await draft.locator("p").last().evaluate(el => getComputedStyle(el, "::after").animationName)).not.toBe("none")
  14 |   await page.screenshot({ path: info.outputPath("markdown-streaming.png") })
  15 |   await expect(draft).toBeHidden({ timeout: 15_000 })
  16 |   await expect(panel.locator("li strong").first()).toHaveText("General background on CNNT's design.")
  17 |   await expect(panel.locator('ol[start="2"] li strong')).toHaveText("This paper's results.")
  18 |   await expect(panel.locator("em")).toHaveText("background")
  19 |   await expect(panel.getByRole("button", { name: "E2E Grounding Paper", exact: true })).toBeVisible()
  20 |   await expect(panel.getByRole("button", { name: "Save to knowledge base", exact: true })).toBeVisible()
  21 |   for (const width of [1440, 390]) {
  22 |     await page.setViewportSize({ width, height: 1000 })
  23 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  24 |     await expect(panel).toBeInViewport({ ratio: 1 })
  25 |     expect(await panel.locator("table").evaluate(el => el.parentElement!.scrollWidth > el.parentElement!.clientWidth)).toBe(true)
  26 |     await page.screenshot({ path: info.outputPath(`markdown-popup-${width}.png`) })
  27 |   }
  28 |   await panel.getByRole("link", { name: "Open full conversation" }).click()
  29 |   await expect(page).toHaveURL(/\/chat\/chat_/)
  30 |   await page.reload()
  31 |   await expect(page.locator("main li strong").first()).toHaveText("General background on CNNT's design.")
  32 |   await expect(page.locator("main")).not.toContainText("**General background")
  33 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  34 |   await page.screenshot({ path: info.outputPath("markdown-saved-mobile.png") })
  35 | })
  36 | 
```