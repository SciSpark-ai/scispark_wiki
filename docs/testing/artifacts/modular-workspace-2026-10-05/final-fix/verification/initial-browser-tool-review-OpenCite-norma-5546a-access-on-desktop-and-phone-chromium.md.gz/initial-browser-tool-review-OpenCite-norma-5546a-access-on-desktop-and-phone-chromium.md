# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tool-review.spec.ts >> OpenCite normalized fixture previews PDF and abstract access on desktop and phone
- Location: e2e/tool-review.spec.ts:55:5

# Error details

```
TypeError: Module "file:///Users/tongshan/Documents/SciSpark_paper_manager/src/lib/extensions/__tests__/fixtures/opencite-output.json" needs an import attribute of "type: json"
```