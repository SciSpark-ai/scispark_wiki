# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tools-library.spec.ts >> configured empty default vault has no optional tool scan, provider call or scheduled work
- Location: e2e/tools-library.spec.ts:6:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -   1
+ Received  + 110

- Array []
+ Array [
+   Object {
+     "capabilities": Array [
+       "field-trends",
+     ],
+     "connectionRequirements": Array [],
+     "connections": Array [],
+     "description": "Discover trends in your research fields.",
+     "enabled": true,
+     "engines": Array [],
+     "installed": true,
+     "kind": "native",
+     "name": "Trending",
+     "outputKinds": Array [
+       "markdown",
+     ],
+     "pinned": true,
+     "readiness": Object {
+       "reasons": Array [],
+       "status": "ready",
+     },
+     "ref": Object {
+       "digest": "0b37ff1d81c355c033f79b9b6a84cf1e2cb7f3e435e9b9a553c318a8ee12792d",
+       "packageId": "scispark.builtin",
+       "skillId": "trending",
+       "version": "1.0.0",
+     },
+   },
+   Object {
+     "capabilities": Array [
+       "paper-search",
+     ],
+     "connectionRequirements": Array [],
+     "connections": Array [],
+     "description": "Find literature for a research question.",
+     "enabled": true,
+     "engines": Array [],
+     "installed": true,
+     "kind": "native",
+     "name": "Find papers",
+     "outputKinds": Array [
+       "papers",
+     ],
+     "pinned": false,
+     "readiness": Object {
+       "reasons": Array [],
+       "status": "ready",
+     },
+     "ref": Object {
+       "digest": "0d7f3c175d55cc447971b616c4a01301c3d89ee2bda586eaafe1ffe3c04f0afb",
+       "packageId": "scispark.builtin",
+       "skillId": "find-papers",
+       "version": "1.0.0",
+     },
+   },
+   Object {
+     "capabilities": Array [
+       "literature-review",
+     ],
+     "connectionRequirements": Array [],
+     "connections": Array [],
+     "description": "Review literature with grounded sources.",
+     "enabled": true,
+     "engines": Array [],
+     "installed": true,
+     "kind": "native",
+     "name": "Deep review",
+     "outputKinds": Array [
+       "markdown",
+     ],
+     "pinned": false,
+     "readiness": Object {
+       "reasons": Array [],
+       "status": "ready",
+     },
+     "ref": Object {
+       "digest": "8b69fc2e4f55afe4a6e4a70439dbedaff27dbd31480267e0d59c05f9b46283b5",
+       "packageId": "scispark.builtin",
+       "skillId": "deep-review",
+       "version": "1.0.0",
+     },
+   },
+   Object {
+     "capabilities": Array [
+       "research-ideas",
+     ],
+     "connectionRequirements": Array [],
+     "connections": Array [],
+     "description": "Develop research ideas from your knowledge base.",
+     "enabled": true,
+     "engines": Array [],
+     "installed": true,
+     "kind": "native",
+     "name": "Idea Spark",
+     "outputKinds": Array [
+       "markdown",
+     ],
+     "pinned": true,
+     "readiness": Object {
+       "reasons": Array [],
+       "status": "ready",
+     },
+     "ref": Object {
+       "digest": "ce1bd085aeeb4439c6d46f695c3481c7491a287b1b11e4416bfa1fe0c630057a",
+       "packageId": "scispark.builtin",
+       "skillId": "idea-spark",
+       "version": "1.0.0",
+     },
+   },
+ ]
```

# Test source

```ts
  1   | import { expect, test } from "@playwright/test"
  2   | import { NodeFsVaultStorage } from "../src/lib/vault/node-fs-storage"
  3   | import { mkdir, writeFile } from "node:fs/promises"
  4   | import { join } from "node:path"
  5   | 
  6   | test("configured empty default vault has no optional tool scan, provider call or scheduled work", async ({ page, request }, info) => {
  7   |   const { readFile } = await import("node:fs/promises")
  8   |   const baseline = JSON.parse(await readFile(join(process.env.SCISPARK_E2E_RUN_DIR!, "evidence", "fresh-profile.json"), "utf8"))
> 9   |   expect(baseline.enabled).toEqual([])
      |                            ^ Error: expect(received).toEqual(expected) // deep equality
  10  |   expect(baseline.runs).toEqual([])
  11  |   expect(baseline.providerCalls).toBe(0)
  12  |   const storage = new NodeFsVaultStorage(process.env.SCISPARK_E2E_VAULT_PATH!)
  13  |   await storage.write(".scispark/tools/state.json", JSON.stringify({ schemaVersion: 1, enabled: [], pins: [], overrides: [], migrated: true, sidebarPins: [] }))
  14  |   let scans = 0
  15  |   page.on("request", req => { if (req.method() === "POST" && /\/api\/(tools\/discovery|skills\/(trending|spark))/.test(req.url())) scans++ })
  16  |   await page.goto("/tools")
  17  |   await expect(page.getByRole("heading", { name: "No tools installed" })).toBeVisible()
  18  |   await page.screenshot({ path: info.outputPath("empty-profileTools.png"), fullPage: true })
  19  |   expect(scans).toBe(0)
  20  |   expect((await (await request.get("/api/tools?view=library")).json()).result.tools.filter((tool: { enabled: boolean }) => tool.enabled)).toEqual([])
  21  | })
  22  | 
  23  | test("Tools empty, installed, explicit local import, consent, setup and errors across desktop and phone", async ({ page, request }, info) => {
  24  |   const storage = new NodeFsVaultStorage(process.env.SCISPARK_E2E_VAULT_PATH!)
  25  |   await request.post("/api/profile", { data: { name: "Ada", role: "Researcher", fields: "Neuroscience", topics: "Speech", feedPrefs: "Methods" } })
  26  |   await storage.write(".scispark/tools/state.json", JSON.stringify({ schemaVersion: 1, enabled: [], pins: [], overrides: [], migrated: true, sidebarPins: [] }))
  27  |   const source = join(process.env.SCISPARK_E2E_RUN_DIR!, "explicit-skills")
  28  |   await mkdir(source)
  29  |   await writeFile(join(source, "SKILL.md"), "---\nname: Research methods helper\ndescription: Compare methods using supplied research context.\nscispark:\n  engines: [api, codex, claude-code]\n---\nCompare supplied sources and preserve limitations.")
  30  |   let discoveryCalls = 0, runs = 0
  31  |   page.on("request", req => { if (req.method() === "POST" && req.url().includes("/api/tools/discovery")) discoveryCalls++; if (req.method() === "POST" && /\/api\/tools\/runs$/.test(req.url())) runs++ })
  32  |   // No execution is required by this library-only check.
  33  |   await page.route("**/api/skills/**", route => route.fulfill({ status: 409, json: { error: "Library fixture does not execute models." } }))
  34  |   await page.goto("/tools")
  35  |   await expect(page.getByRole("heading", { name: "No tools installed" })).toBeVisible()
  36  |   await expect(page.getByRole("link", { name: "Trending", exact: true })).toHaveCount(0)
  37  |   await expect(page.getByRole("link", { name: "Graph", exact: true })).toBeVisible()
  38  |   await page.screenshot({ path: info.outputPath("tools-empty-desktop.png"), fullPage: true, animations: "disabled" })
  39  |   await page.getByRole("button", { name: "Catalog", exact: true }).click()
  40  |   const trending = page.locator("article").filter({ has: page.getByRole("heading", { name: "Trending", exact: true }) })
  41  |   await trending.getByRole("button", { name: "Add tool", exact: true }).click()
  42  |   await page.getByRole("button", { name: "Installed", exact: true }).click()
  43  |   await trending.getByRole("button", { name: "Pin to sidebar", exact: true }).click()
  44  |   await expect(page.getByRole("link", { name: "Trending", exact: true })).toBeVisible()
  45  |   await page.getByRole("button", { name: "Add tools", exact: true }).click()
  46  |   const dialog = page.getByRole("dialog")
  47  |   await expect(dialog).toBeFocused(); await page.keyboard.press("Shift+Tab"); expect(await dialog.evaluate(el => el.contains(document.activeElement))).toBe(true)
  48  |   await page.keyboard.press("Escape"); await expect(page.getByRole("button", { name: "Add tools", exact: true })).toBeFocused()
  49  |   await page.getByRole("button", { name: "Find installed skills", exact: true }).click()
  50  |   await expect(dialog.getByText("Folder path", { exact: true })).toBeVisible()
  51  |   expect(discoveryCalls).toBe(0)
  52  |   await dialog.getByLabel("Folder path", { exact: true }).fill(source)
  53  |   await page.screenshot({ path: info.outputPath("tools-consent-desktop.png"), fullPage: true, animations: "disabled" })
  54  |   await dialog.getByLabel(/Allow access/).check(); await dialog.getByRole("button", { name: "Discover skills" }).click()
  55  |   await expect(dialog.getByRole("heading", { name: "Research methods helper" })).toBeVisible(); expect(discoveryCalls).toBe(2)
  56  |   await dialog.getByRole("button", { name: "Review skill" }).click()
  57  |   await dialog.getByLabel(/I reviewed/).check(); await dialog.getByRole("button", { name: "Confirm import" }).click()
  58  |   await expect(dialog.getByText(/Import saved/)).toBeVisible()
  59  |   await dialog.getByRole("button", { name: "Close", exact: true }).click()
  60  |   await expect(page.getByRole("heading", { name: "Research methods helper", exact: true })).toBeVisible()
  61  |   await page.screenshot({ path: info.outputPath("tools-installed-desktop.png"), fullPage: true, animations: "disabled" })
  62  |   await page.getByRole("button", { name: "Catalog", exact: true }).click()
  63  |   await page.locator("article").filter({ has: page.getByRole("heading", { name: "OpenCite", exact: true }) }).getByRole("button", { name: "Review tool" }).click()
  64  |   await dialog.getByRole("button", { name: "Preview OpenCite" }).click()
  65  |   await dialog.getByLabel(/I reviewed/).check(); await dialog.getByRole("button", { name: "Confirm import" }).click()
  66  |   await expect(dialog.getByText(/Import saved/)).toBeVisible()
  67  |   await page.screenshot({ path: info.outputPath("tools-setup-desktop.png"), fullPage: true, animations: "disabled" })
  68  |   await dialog.getByRole("button", { name: "Close", exact: true }).click()
  69  |   await page.getByRole("button", { name: "Installed", exact: true }).click()
  70  |   await expect(page.getByRole("button", { name: "Installed", exact: true })).toHaveAttribute("aria-pressed", "true")
  71  |   await page.setViewportSize({ width: 390, height: 844 })
  72  |   await page.screenshot({ path: info.outputPath("tools-installed-phone.png"), fullPage: true, animations: "disabled" })
  73  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  74  |   const openCite = page.locator("article").filter({ has: page.getByRole("heading", { name: "OpenCite", exact: true }) })
  75  |   await openCite.getByRole("button", { name: "Manage" }).click()
  76  |   await expect(dialog.getByText(/Changes apply to new runs/)).toBeVisible()
  77  |   await page.screenshot({ path: info.outputPath("tools-settings-phone.png"), fullPage: true, animations: "disabled" })
  78  |   await page.keyboard.press("Escape")
  79  |   await page.getByRole("button", { name: "Add tools", exact: true }).click(); await dialog.getByRole("button", { name: "Local files or folder" }).click()
  80  |   await dialog.getByLabel("Folder path", { exact: true }).fill(join(source, "missing")); await dialog.getByRole("button", { name: "Preview selected folder" }).click()
  81  |   await expect(dialog.getByRole("alert")).toBeVisible()
  82  |   await page.screenshot({ path: info.outputPath("tools-error-phone.png"), fullPage: true, animations: "disabled" })
  83  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  84  |   await page.keyboard.press("Escape")
  85  |   await expect(dialog).toBeHidden()
  86  |   await page.setViewportSize({ width: 1280, height: 900 })
  87  |   await page.getByRole("button", { name: /dark mode/i }).click()
  88  |   await page.screenshot({ path: info.outputPath("tools-installed-dark.png"), fullPage: true, animations: "disabled" })
  89  |   expect(runs).toBe(0)
  90  | })
  91  | 
  92  | test("import hands an unbound supporting connection to root Manage without claiming readiness", async ({ page, request }, info) => {
  93  |   const storage = new NodeFsVaultStorage(process.env.SCISPARK_E2E_VAULT_PATH!)
  94  |   const source = join(process.env.SCISPARK_E2E_RUN_DIR!, "supporting-connection")
  95  |   const rootSource = join(process.env.SCISPARK_E2E_RUN_DIR!, "supporting-root")
  96  |   await Promise.all([mkdir(source), mkdir(rootSource)])
  97  |   await writeFile(join(source, "SKILL.md"), `---\nname: Literature connection helper\ndescription: Search scholarly sources.\nscispark: ${JSON.stringify({ engines: ["api"], connections: ["semantic-scholar"], setup: { commands: [], runtimes: [], unsupported: [], connectionAdapter: "scispark-http-v1" } })}\n---\nUse the declared source connection.`)
  98  |   const previewResponse = await request.post("/api/tools/imports", { data: { source: { kind: "local-folder", path: source } } })
  99  |   expect(previewResponse.ok()).toBe(true)
  100 |   const preview = (await previewResponse.json()).result
  101 |   const confirmed = await request.post(`/api/tools/imports/${preview.id}`, { data: { action: "confirm", selected: [preview.tools[0].manifest.ref], proposals: [preview.tools[0].proposal] } })
  102 |   expect(confirmed.ok()).toBe(true)
  103 |   const helper = (await confirmed.json()).result.preview.tools[0].manifest.ref
  104 |   // Fixture topology: retain the owned immutable helper, but no standalone binding.
  105 |   await storage.write(".scispark/tools/state.json", JSON.stringify({ schemaVersion: 1, enabled: [], pins: [], overrides: [], migrated: true, sidebarPins: [] }))
  106 |   const settings = JSON.parse((await storage.read(".scispark/settings.json"))!)
  107 |   await storage.write(".scispark/settings.json", JSON.stringify({ ...settings, paperSources: { s2: { apiKey: "disposable-fixture-only" } } }))
  108 |   await writeFile(join(rootSource, "SKILL.md"), `---\nname: Literature research root\ndescription: Compare supplied evidence.\nscispark: ${JSON.stringify({ engines: ["api"], dependencies: [helper] })}\n---\nUse the declared supporting skill.`)
  109 |   let runs = 0
```