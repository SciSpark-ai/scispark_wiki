# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tools-library.spec.ts >> import hands an unbound supporting connection to root Manage without claiming readiness
- Location: e2e/tools-library.spec.ts:92:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog').getByText('Literature connection helper', { exact: true })
Expected: visible
Error: strict mode violation: getByRole('dialog').getByText('Literature connection helper', { exact: true }) resolved to 2 elements:
    1) <span class="block text-balance">Literature connection helper</span> aka getByText('Literature connection helper').first()
    2) <span class="block text-balance">Literature connection helper</span> aka getByText('Literature connection helper').nth(1)

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByRole('dialog').getByText('Literature connection helper', { exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - alert [ref=e2]
  - generic [ref=e3]:
    - generic [ref=e4]:
      - complementary [ref=e6]:
        - generic [ref=e7]:
          - button "Close sidebar" [ref=e8]
          - img "SciSpark" [ref=e12]
          - button "Switch to light mode" [ref=e13]
        - navigation [ref=e20]:
          - generic [ref=e21]:
            - generic [ref=e22]: Discover
            - link "Home" [ref=e23] [cursor=pointer]:
              - /url: /
            - link "Sparky" [ref=e28] [cursor=pointer]:
              - /url: /chat
          - generic [ref=e32]:
            - generic [ref=e33]: Knowledge
            - link "Wiki" [ref=e34] [cursor=pointer]:
              - /url: /wiki
            - link "Graph" [ref=e38] [cursor=pointer]:
              - /url: /viz
            - link "Projects" [ref=e45] [cursor=pointer]:
              - /url: /projects
          - generic [ref=e49]:
            - generic [ref=e50]: Tools
            - link "Tools" [ref=e51] [cursor=pointer]:
              - /url: /tools
          - separator [ref=e55]
          - link "History" [ref=e56] [cursor=pointer]:
            - /url: /history
          - list "Recent chats" [ref=e61]:
            - listitem [ref=e62]:
              - link "MODULAR:scope Compare supplied evidence Oct 6, 1:53:11 AM" [ref=e63] [cursor=pointer]:
                - /url: /chat/chat_29e3a566-c872-43b3-84af-e038759bab7d
                - generic [ref=e64]: MODULAR:scope Compare supplied evidence
                - time [ref=e65]: Oct 6, 1:53:11 AM
            - listitem [ref=e66]:
              - link "MODULAR:choice Compare the supplied research evidence Oct 6, 1:53:00 AM" [ref=e67] [cursor=pointer]:
                - /url: /chat/chat_1797a25b-e87e-434f-802a-bc30d6074d55
                - generic [ref=e68]: MODULAR:choice Compare the supplied research evidence
                - time [ref=e69]: Oct 6, 1:53:00 AM
        - generic [ref=e70]:
          - separator [ref=e71]
          - button "Profile menu" [ref=e73]:
            - generic [ref=e74]: A
            - generic [ref=e75]:
              - paragraph [ref=e76]: Ada
              - paragraph [ref=e77]: Local profile
      - main [ref=e78]:
        - generic [ref=e80]:
          - generic [ref=e81]:
            - heading "Tools" [level=1] [ref=e83]
            - button "Add tools" [ref=e85]
          - group "Tools view" [ref=e86]:
            - button "Installed" [pressed] [ref=e87]
            - button "Catalog" [ref=e88]
          - article [ref=e90]:
            - heading "Literature research root" [level=2] [ref=e91]
            - paragraph [ref=e92]: Compare supplied evidence.
            - paragraph [ref=e93]: Enabled · Setup needed
            - paragraph [ref=e94]: Connect Semantic Scholar in Manage, then add its key in Settings.
            - generic [ref=e95]:
              - link "Use tool" [ref=e96] [cursor=pointer]:
                - /url: /chat?tool=%7B%22packageId%22%3A%22import.3c33f4015d592c0164eeecba821ce4fc%22%2C%22skillId%22%3A%22SKILL.md%22%2C%22version%22%3A%229d06e3088427408a516a469903e2fce8249a18bda5052592910755942c72ff63%22%2C%22digest%22%3A%225957c35dcf7e77578cb8965ad5a67cd242dd55282337c7da25f1d09d8b97f6c9%22%7D
              - button "Pin to sidebar" [ref=e97]
              - button "Manage" [ref=e98]
          - generic [ref=e99]:
            - paragraph [ref=e100]: Bring skills from an installed agent.
            - button "Find installed skills" [ref=e101]
            - button "Dismiss" [ref=e102]
          - dialog "Review import" [ref=e104]:
            - generic [ref=e105]:
              - heading "Review import" [level=2] [ref=e106]
              - button "Close" [ref=e107]
            - group [ref=e108]:
              - article [ref=e109]:
                - generic [ref=e110]:
                  - checkbox "Literature research root" [checked] [disabled] [ref=e111]
                  - text: Literature research root
                - paragraph [ref=e112]: Compare supplied evidence.
                - paragraph [ref=e113]: "Access: Provided research context. Connections: None."
                - paragraph [ref=e114]:
                  - generic [ref=e115]: Supporting tools
                  - generic [ref=e116]: Literature connection helper
                - paragraph [ref=e117]: "Needs setup: Connect Semantic Scholar in Manage, then add its key in Settings."
                - group [ref=e118]:
                  - generic "Resources and setup plan" [ref=e119] [cursor=pointer]
                - paragraph [ref=e120]:
                  - generic [ref=e121]: Supporting tool needing setup
                  - generic [ref=e122]: Literature connection helper
                - generic [ref=e123]:
                  - paragraph [ref=e124]: Continue in Manage to connect services or review environment setup.
                  - button "Manage setup" [ref=e125]
              - status [ref=e126]: Import saved.
              - button "Refresh setup status" [ref=e127]
    - button "Open Sparky chat" [ref=e130] [cursor=pointer]
```

# Test source

```ts
  22  | 
  23  | test("Tools empty, installed, explicit local import, consent, setup and errors across desktop and phone", async ({ page, request }, info) => {
  24  |   const storage = new NodeFsVaultStorage(process.env.SCISPARK_E2E_VAULT_PATH!)
  25  |   await request.post("/api/profile", { data: { name: "Ada", role: "Researcher", fields: "Neuroscience", topics: "Speech", feedPrefs: "Methods" } })
  26  |   await storage.write(".scispark/tools/state.json", JSON.stringify({ schemaVersion: 1, enabled: [], pins: [], overrides: [], migrated: true, sidebarPins: [] }))
  27  |   const source = join(process.env.SCISPARK_E2E_RUN_DIR!, "explicit-skills")
  28  |   await mkdir(source)
  29  |   await writeFile(join(source, "SKILL.md"), "---\nname: Research methods helper\ndescription: Compare methods using supplied research context.\nscispark:\n  engines: [api, codex, claude-code]\n---\nCompare supplied sources and preserve limitations.")
  30  |   let discoveryCalls = 0, runs = 0
  31  |   page.on("request", req => { if (req.method() === "POST" && req.url().includes("/api/tools/discovery")) discoveryCalls++; if (req.method() === "POST" && /\/api\/tools\/runs$/.test(req.url())) runs++ })
  32  |   // No execution is required by this library-only check.
  33  |   await page.route("**/api/skills/**", route => route.fulfill({ status: 409, json: { error: "Library fixture does not execute models." } }))
  34  |   await page.goto("/tools")
  35  |   await expect(page.getByRole("heading", { name: "No tools installed" })).toBeVisible()
  36  |   await expect(page.getByRole("link", { name: "Trending", exact: true })).toHaveCount(0)
  37  |   await expect(page.getByRole("link", { name: "Graph", exact: true })).toBeVisible()
  38  |   await page.screenshot({ path: info.outputPath("tools-empty-desktop.png"), fullPage: true, animations: "disabled" })
  39  |   await page.getByRole("button", { name: "Catalog", exact: true }).click()
  40  |   const trending = page.locator("article").filter({ has: page.getByRole("heading", { name: "Trending", exact: true }) })
  41  |   await trending.getByRole("button", { name: "Add tool", exact: true }).click()
  42  |   await page.getByRole("button", { name: "Installed", exact: true }).click()
  43  |   await trending.getByRole("button", { name: "Pin to sidebar", exact: true }).click()
  44  |   await expect(page.getByRole("link", { name: "Trending", exact: true })).toBeVisible()
  45  |   await page.getByRole("button", { name: "Add tools", exact: true }).click()
  46  |   const dialog = page.getByRole("dialog")
  47  |   await expect(dialog).toBeFocused(); await page.keyboard.press("Shift+Tab"); expect(await dialog.evaluate(el => el.contains(document.activeElement))).toBe(true)
  48  |   await page.keyboard.press("Escape"); await expect(page.getByRole("button", { name: "Add tools", exact: true })).toBeFocused()
  49  |   await page.getByRole("button", { name: "Find installed skills", exact: true }).click()
  50  |   await expect(dialog.getByText("Folder path", { exact: true })).toBeVisible()
  51  |   expect(discoveryCalls).toBe(0)
  52  |   await dialog.getByLabel("Folder path", { exact: true }).fill(source)
  53  |   await page.screenshot({ path: info.outputPath("tools-consent-desktop.png"), fullPage: true, animations: "disabled" })
  54  |   await dialog.getByLabel(/Allow access/).check(); await dialog.getByRole("button", { name: "Discover skills" }).click()
  55  |   await expect(dialog.getByRole("heading", { name: "Research methods helper" })).toBeVisible(); expect(discoveryCalls).toBe(2)
  56  |   await dialog.getByRole("button", { name: "Review skill" }).click()
  57  |   await dialog.getByLabel(/I reviewed/).check(); await dialog.getByRole("button", { name: "Confirm import" }).click()
  58  |   await expect(dialog.getByText(/Import saved/)).toBeVisible()
  59  |   await dialog.getByRole("button", { name: "Close", exact: true }).click()
  60  |   await expect(page.getByRole("heading", { name: "Research methods helper", exact: true })).toBeVisible()
  61  |   await page.screenshot({ path: info.outputPath("tools-installed-desktop.png"), fullPage: true, animations: "disabled" })
  62  |   await page.getByRole("button", { name: "Catalog", exact: true }).click()
  63  |   await page.locator("article").filter({ has: page.getByRole("heading", { name: "OpenCite", exact: true }) }).getByRole("button", { name: "Review tool" }).click()
  64  |   await dialog.getByRole("button", { name: "Preview OpenCite" }).click()
  65  |   await dialog.getByLabel(/I reviewed/).check(); await dialog.getByRole("button", { name: "Confirm import" }).click()
  66  |   await expect(dialog.getByText(/Import saved/)).toBeVisible()
  67  |   await page.screenshot({ path: info.outputPath("tools-setup-desktop.png"), fullPage: true, animations: "disabled" })
  68  |   await dialog.getByRole("button", { name: "Close", exact: true }).click()
  69  |   await page.getByRole("button", { name: "Installed", exact: true }).click()
  70  |   await expect(page.getByRole("button", { name: "Installed", exact: true })).toHaveAttribute("aria-pressed", "true")
  71  |   await page.setViewportSize({ width: 390, height: 844 })
  72  |   await page.screenshot({ path: info.outputPath("tools-installed-phone.png"), fullPage: true, animations: "disabled" })
  73  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  74  |   const openCite = page.locator("article").filter({ has: page.getByRole("heading", { name: "OpenCite", exact: true }) })
  75  |   await openCite.getByRole("button", { name: "Manage" }).click()
  76  |   await expect(dialog.getByText(/Changes apply to new runs/)).toBeVisible()
  77  |   await page.screenshot({ path: info.outputPath("tools-settings-phone.png"), fullPage: true, animations: "disabled" })
  78  |   await page.keyboard.press("Escape")
  79  |   await page.getByRole("button", { name: "Add tools", exact: true }).click(); await dialog.getByRole("button", { name: "Local files or folder" }).click()
  80  |   await dialog.getByLabel("Folder path", { exact: true }).fill(join(source, "missing")); await dialog.getByRole("button", { name: "Preview selected folder" }).click()
  81  |   await expect(dialog.getByRole("alert")).toBeVisible()
  82  |   await page.screenshot({ path: info.outputPath("tools-error-phone.png"), fullPage: true, animations: "disabled" })
  83  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  84  |   await page.keyboard.press("Escape")
  85  |   await expect(dialog).toBeHidden()
  86  |   await page.setViewportSize({ width: 1280, height: 900 })
  87  |   await page.getByRole("button", { name: /dark mode/i }).click()
  88  |   await page.screenshot({ path: info.outputPath("tools-installed-dark.png"), fullPage: true, animations: "disabled" })
  89  |   expect(runs).toBe(0)
  90  | })
  91  | 
  92  | test("import hands an unbound supporting connection to root Manage without claiming readiness", async ({ page, request }, info) => {
  93  |   const storage = new NodeFsVaultStorage(process.env.SCISPARK_E2E_VAULT_PATH!)
  94  |   const source = join(process.env.SCISPARK_E2E_RUN_DIR!, "supporting-connection")
  95  |   const rootSource = join(process.env.SCISPARK_E2E_RUN_DIR!, "supporting-root")
  96  |   await Promise.all([mkdir(source), mkdir(rootSource)])
  97  |   await writeFile(join(source, "SKILL.md"), `---\nname: Literature connection helper\ndescription: Search scholarly sources.\nscispark: ${JSON.stringify({ engines: ["api"], connections: ["semantic-scholar"], setup: { commands: [], runtimes: [], unsupported: [], connectionAdapter: "scispark-http-v1" } })}\n---\nUse the declared source connection.`)
  98  |   const previewResponse = await request.post("/api/tools/imports", { data: { source: { kind: "local-folder", path: source } } })
  99  |   expect(previewResponse.ok()).toBe(true)
  100 |   const preview = (await previewResponse.json()).result
  101 |   const confirmed = await request.post(`/api/tools/imports/${preview.id}`, { data: { action: "confirm", selected: [preview.tools[0].manifest.ref], proposals: [preview.tools[0].proposal] } })
  102 |   expect(confirmed.ok()).toBe(true)
  103 |   const helper = (await confirmed.json()).result.preview.tools[0].manifest.ref
  104 |   // Fixture topology: retain the owned immutable helper, but no standalone binding.
  105 |   await storage.write(".scispark/tools/state.json", JSON.stringify({ schemaVersion: 1, enabled: [], pins: [], overrides: [], migrated: true, sidebarPins: [] }))
  106 |   const settings = JSON.parse((await storage.read(".scispark/settings.json"))!)
  107 |   await storage.write(".scispark/settings.json", JSON.stringify({ ...settings, paperSources: { s2: { apiKey: "disposable-fixture-only" } } }))
  108 |   await writeFile(join(rootSource, "SKILL.md"), `---\nname: Literature research root\ndescription: Compare supplied evidence.\nscispark: ${JSON.stringify({ engines: ["api"], dependencies: [helper] })}\n---\nUse the declared supporting skill.`)
  109 |   let runs = 0
  110 |   page.on("request", req => { if (req.method() === "POST" && /\/api\/tools\/runs$/.test(req.url())) runs++ })
  111 |   await page.goto("/tools")
  112 |   await page.getByRole("button", { name: "Add tools", exact: true }).click()
  113 |   const dialog = page.getByRole("dialog")
  114 |   await dialog.getByRole("button", { name: "Local files or folder" }).click()
  115 |   await dialog.getByLabel("Folder path", { exact: true }).fill(rootSource)
  116 |   await dialog.getByRole("button", { name: "Preview selected folder" }).click()
  117 |   await dialog.getByLabel(/I reviewed/).check()
  118 |   await dialog.getByRole("button", { name: "Confirm import" }).click()
  119 |   await expect(dialog.getByText("Import saved.", { exact: true })).toBeVisible()
  120 |   await expect(dialog.getByText(/Needs setup:/)).toBeVisible()
  121 |   await expect(dialog.getByText("Supporting tool needing setup", { exact: true })).toBeVisible()
> 122 |   await expect(dialog.getByText("Literature connection helper", { exact: true })).toBeVisible()
      |                                                                                   ^ Error: expect(locator).toBeVisible() failed
  123 |   await expect(dialog.getByText(/^Ready:/)).toHaveCount(0)
  124 |   await page.screenshot({ path: info.outputPath("supporting-import-desktop.png"), fullPage: true, animations: "disabled" })
  125 |   await page.setViewportSize({ width: 390, height: 844 })
  126 |   await page.screenshot({ path: info.outputPath("supporting-import-phone.png"), fullPage: true, animations: "disabled" })
  127 |   expect(await dialog.evaluate(el => el.scrollWidth <= el.clientWidth)).toBe(true)
  128 |   await dialog.getByRole("button", { name: "Manage setup" }).click()
  129 |   await expect(dialog).toHaveAttribute("aria-label", "Literature research root")
  130 |   await expect(dialog).toBeFocused()
  131 |   await page.keyboard.press("Shift+Tab")
  132 |   expect(await dialog.evaluate(el => el.contains(document.activeElement))).toBe(true)
  133 |   const connect = dialog.getByRole("button", { name: "Connect Semantic Scholar for Literature connection helper" })
  134 |   await expect(connect).toBeVisible()
  135 |   await page.setViewportSize({ width: 390, height: 844 })
  136 |   await page.screenshot({ path: info.outputPath("supporting-manage-phone.png"), fullPage: true, animations: "disabled" })
  137 |   expect(await dialog.evaluate(el => el.scrollWidth <= el.clientWidth)).toBe(true)
  138 |   await connect.click()
  139 |   await expect(dialog.getByText("Change saved for this profile.")).toBeVisible()
  140 |   await expect(dialog.getByText("Supporting tool connection", { exact: true })).toHaveCount(1)
  141 |   await page.keyboard.press("Escape")
  142 |   const card = page.locator("article").filter({ has: page.getByRole("heading", { name: "Literature research root", exact: true }) })
  143 |   await expect(card.getByText("Enabled · Ready", { exact: true })).toBeVisible()
  144 |   await card.getByRole("button", { name: "Manage" }).click()
  145 |   await page.keyboard.press("Escape")
  146 |   await expect(card.getByRole("button", { name: "Manage" })).toBeFocused()
  147 |   await expect(page.getByRole("heading", { name: "Literature connection helper", exact: true })).toHaveCount(0)
  148 |   expect(runs).toBe(0)
  149 | })
  150 | 
  151 | 
  152 | test("GitHub and ZIP fixture imports use the reviewed UI and network misses fail closed", async ({ page, request }) => {
  153 |   const { zipSync, strToU8 } = await import("fflate")
  154 |   const { skill, resetTools } = await import("./fixtures/modular")
  155 |   await resetTools()
  156 |   const root = process.env.SCISPARK_E2E_RUN_DIR!
  157 |   await writeFile(join(root, "github-fixture.zip"), zipSync({ "fixture-root/SKILL.md": strToU8(skill("GitHub fixture evidence")) }))
  158 |   await page.goto("/tools")
  159 |   await page.getByRole("button", { name: "Add tools", exact: true }).click()
  160 |   const dialog = page.getByRole("dialog")
  161 |   await dialog.getByRole("button", { name: "GitHub", exact: true }).click()
  162 |   await dialog.getByLabel("GitHub repository").fill("https://github.com/scispark-fixture/modular")
  163 |   await dialog.getByRole("button", { name: "Preview import", exact: true }).click()
  164 |   await expect(dialog.getByRole("checkbox", { name: "GitHub fixture evidence", exact: true })).toBeVisible()
  165 |   await dialog.getByLabel(/I reviewed/).check(); await dialog.getByRole("button", { name: "Confirm import" }).click()
  166 |   await expect(dialog.getByText("Import saved.", { exact: true })).toBeVisible()
  167 |   await dialog.getByRole("button", { name: "Close", exact: true }).click()
  168 |   await page.getByRole("button", { name: "Add tools", exact: true }).click()
  169 |   await dialog.getByRole("button", { name: "Local files or folder" }).click()
  170 |   await dialog.getByLabel("Or upload a ZIP file").setInputFiles({ name: "fixture.zip", mimeType: "application/zip", buffer: Buffer.from(zipSync({ "SKILL.md": strToU8(skill("ZIP fixture evidence")) })) })
  171 |   await expect(dialog.getByRole("checkbox", { name: "ZIP fixture evidence", exact: true })).toBeVisible()
  172 |   await dialog.getByLabel(/I reviewed/).check(); await dialog.getByRole("button", { name: "Confirm import" }).click()
  173 |   await expect(dialog.getByText("Import saved.", { exact: true })).toBeVisible()
  174 |   const missing = await request.post("/api/tools/imports", { data: { source: { kind: "github", url: "https://github.com/scispark-fixture/unmatched" } } })
  175 |   expect(missing.status()).toBe(409)
  176 | })
  177 | 
```