from pathlib import Path
import hashlib,json,gzip,re,subprocess
repo=Path.cwd();root=repo/'docs/testing/artifacts/modular-workspace-2026-10-05';out=root/'final-fix'
errors=[];raws=0;jsons=0;links=0
for row in json.loads((root/'raw-output-index.json').read_text()):
 p=root/row['path'];raw=gzip.decompress(p.read_bytes());assert len(raw)==row['rawBytes'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'],p;raws+=1
for p in root.rglob('*'):
 if not p.is_file():continue
 name=p.name;raw=gzip.decompress(p.read_bytes()) if name.endswith('.gz') else p.read_bytes();name=name.removesuffix('.gz')
 if name.endswith('.json'):json.loads(raw);jsons+=1
 elif name.endswith('.jsonl'):
  for line in raw.splitlines():
   if line.strip():json.loads(line);jsons+=1
files=[repo/'README.md',repo/'docs/FEATURE_GUIDE.md',*repo.glob('docs/superpowers/*/2026-10-05-modular*'),repo/'docs/testing/2026-10-05-modular-workspace.md',repo/'docs/testing/modular-workspace-live-check.md',*root.rglob('*.md')]
for p in files:
 text=re.sub(r'```.*?```','',p.read_text(),flags=re.S)
 for dest in re.findall(r'!?\[[^\]\n]*\]\(([^)]+)\)',text):
  dest=dest.split('#')[0].split(' "')[0].strip('<>')
  if not dest or re.match(r'^[a-zA-Z]+:',dest):continue
  path=Path(dest) if dest.startswith('/') else p.parent/dest
  links+=1
  if not path.exists():errors.append(f'{p.relative_to(repo)}: {dest}')
print(json.dumps({'rawRecords':raws,'jsonRecords':jsons,'links':links,'missing':errors},indent=2))
