from pathlib import Path
import shutil,json
repo=Path.cwd();scratch=repo/'.superpowers/sdd/2026-10-05-modular-workspace';root=repo/'docs/testing/artifacts/modular-workspace-2026-10-05/final-fix';screens=root/'screens';screens.mkdir(exist_ok=True)
records=[('YMPJiP','empty-profileTools.png','empty-tools.png'),('6mrcUz','ambiguousSparky.png','chooser.png'),('YMPJiP','active-after-navigation.png','active-after-leave.png'),('YMPJiP','completed-source-linked-results.png','completed-source-linked.png'),('xhgGUp','supporting-import-phone.png','supporting-import-phone.png'),('xhgGUp','supporting-manage-phone.png','supporting-manage-phone.png'),('YMPJiP','selected-tool-composer-phone.png','selected-tool-composer-phone.png'),('YMPJiP','opencite-preview-desktop.png','opencite-preview-desktop.png'),('YMPJiP','opencite-preview-phone.png','opencite-preview-phone.png'),('YMPJiP','opencite-preview-phone-access.png','opencite-preview-phone-access.png')]
for run,name,target in records:
 found=list((Path('/tmp/scispark-modular-final-fix-evidence')/('acceptance-'+run)/'browser').rglob(name));assert len(found)==1;shutil.copy2(found[0],screens/target)
(screens/'capture-index.json').write_text(json.dumps([{'file':target,'acceptance':run,'originalFilename':name,'visuallyInspected':True} for run,name,target in records],indent=2)+'\n')
p=Path('/tmp/preserve-final-fix.py');s=p.read_text().replace("('acceptance-OU1jk0','core-final')","('acceptance-OU1jk0','core-final'),('acceptance-6mrcUz','choice-final')");p.write_text(s)
gates='''| Gate | Current evidence |
| --- | --- |
| Typecheck | Exit0, 4.73s; final production builds also typechecked |
| Lint | Exit0, 18.46s; only the baseline ConnectAiCard hook warning |
| Full Vitest | **3316 passed / 24 skipped**, 311 passed /8 skipped files; 37.89s suite /38.80s wrapper |
| Final chooser regression | **40/40**, 1.47s, after strengthening the hash-version case |
| Regular build | Exit0, **28.26s**, `.next-modular-final-fix-regular-v3` |
| Acceptance build | Exit0, **25.43s**, `.next-modular-final-fix-acceptance-v3` |
| Modular six-spec coverage | v2 suite **12 passed/1 locator failure**, then affected import handoff **1/1** (4.2s); final v3 chooser **1/1** (14.6s) |
| Core six production specs | **6/6**, 49.1s; Markdown, paper context, selection, feed, review and restart |

The last change only removes an opaque version from the collapsed chooser summary. Its strengthened40-test component suite, fresh regular/acceptance builds and production chooser rerun pass. The full offline suite and remaining v2 browser scopes are reused because their product behavior is unchanged; these are not represented as a single fresh full-suite run on v3. All earlier failures and build variants remain retained.'''
p=scratch/'final-fix-report.md';s=p.read_text().replace('FINAL_GATE_RESULTS_PENDING',gates);p.write_text(s)
p=repo/'docs/testing/2026-10-05-modular-workspace.md';s=p.read_text();needle='Current final gate results and screenshots are recorded below after the isolated browser checks. Previous Task19/20 results are preserved as historical evidence, not represented as checks of changed code.'
block=gates+'''

Current raw [gate metadata](artifacts/modular-workspace-2026-10-05/final-fix/verification/results.json), [full Vitest](artifacts/modular-workspace-2026-10-05/final-fix/verification/vitest.log.gz), [regular build](artifacts/modular-workspace-2026-10-05/final-fix/verification/build-regular/build-result.json), [acceptance build](artifacts/modular-workspace-2026-10-05/final-fix/verification/build-acceptance/build-result.json), [modular six-spec log](artifacts/modular-workspace-2026-10-05/final-fix/verification/browser-modular-final-suite.log.gz), [import correction](artifacts/modular-workspace-2026-10-05/final-fix/verification/browser-modular-targeted.log.gz), [final chooser](artifacts/modular-workspace-2026-10-05/final-fix/verification/browser-choice-final.log.gz) and [core six](artifacts/modular-workspace-2026-10-05/final-fix/verification/browser-core.log.gz) preserve exact scopes. R78 fixes truly-empty fixture registration ordering; R79 preserves ordinary explain routing for the synthetic Markdown marker. No product readiness override or live command is used.

Current visually inspected production captures:

| Capture | Evidence |
| --- | --- |
| Empty profile Tools | [Empty Tools](artifacts/modular-workspace-2026-10-05/final-fix/screens/empty-tools.png) |
| Single chooser prompt, human summaries | [Chooser](artifacts/modular-workspace-2026-10-05/final-fix/screens/chooser.png) |
| Active run after navigation, human title | [Active](artifacts/modular-workspace-2026-10-05/final-fix/screens/active-after-leave.png) |
| Completed source-linked result | [Completed](artifacts/modular-workspace-2026-10-05/final-fix/screens/completed-source-linked.png) |
| Supporting names and setup on phone | [Import](artifacts/modular-workspace-2026-10-05/final-fix/screens/supporting-import-phone.png), [Manage](artifacts/modular-workspace-2026-10-05/final-fix/screens/supporting-manage-phone.png) |
| Selected-tool composer on phone | [Composer](artifacts/modular-workspace-2026-10-05/final-fix/screens/selected-tool-composer-phone.png) |
| Actual normalized OpenCite fixture | [Desktop](artifacts/modular-workspace-2026-10-05/final-fix/screens/opencite-preview-desktop.png), [phone access/reasons](artifacts/modular-workspace-2026-10-05/final-fix/screens/opencite-preview-phone-access.png) |

The captures retain rounded content surfaces and existing research interactions. Phone content is contained without horizontal overflow; supporting names use separate label/name lines. OpenCite presentation uses the real normalizer with synthetic source/PDF data, not actual command execution. Previous Task19/20 gates below are historical.
'''
assert needle in s;s=s.replace(needle,block);p.write_text(s)
