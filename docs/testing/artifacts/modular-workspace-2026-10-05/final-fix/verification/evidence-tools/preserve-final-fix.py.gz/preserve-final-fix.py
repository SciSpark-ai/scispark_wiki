from pathlib import Path
import json,gzip,hashlib,re,subprocess
repo=Path.cwd();scratch=repo/'.superpowers/sdd/2026-10-05-modular-workspace';root=repo/'docs/testing/artifacts/modular-workspace-2026-10-05';out=root/'final-fix';out.mkdir(exist_ok=True)
index=json.loads((root/'raw-output-index.json').read_text());index=[e for e in index if not e['path'].startswith('final-fix/')]
def put(src,dest,compress=False):
 raw=src.read_bytes();target=out/dest
 if compress:target=Path(str(target)+'.gz')
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0) if compress else raw)
 if compress:index.append(dict(path=str(target.relative_to(root)),originalPath=str(src.relative_to(repo)) if src.is_relative_to(repo) else str(src),rawSha256=hashlib.sha256(raw).hexdigest(),rawBytes=len(raw)))
for name in ['final-review.md','final-fix-brief.md','task-20-review.md','final-fix-report.md']:
 if (scratch/name).exists():put(scratch/name,name)
for p in sorted(scratch.glob('final-review-*')):
 if p.is_file():put(p,Path('review-repro')/p.name,True)
for p in sorted((scratch/'verification/final-fix').rglob('*')):
 if p.is_file():put(p,Path('verification')/p.relative_to(scratch/'verification/final-fix'),p.suffix!='.json')
for name in ['build-final-fix.py','regenerate-owned-catalog.ts','regenerate-owned-catalog.test.ts','regenerate-owned-catalog.config.mts']:
 if (scratch/name).exists():put(scratch/name,Path('harness')/name,True)
for name,label in [('acceptance-zkgPsP','modular-initial'),('acceptance-KEdQVx','modular-before-visual'),('acceptance-EYrbum','core-initial'),('acceptance-YMPJiP','modular-final-suite'),('acceptance-xhgGUp','modular-import-final'),('acceptance-OU1jk0','core-final'),('acceptance-6mrcUz','choice-final')]:
 base=Path('/tmp/scispark-modular-final-fix-evidence')/name
 for p in sorted(base.rglob('*')):
  if p.is_file():put(p,Path('browser')/label/p.relative_to(base),p.suffix in ['.log','.txt'])
# Historical originals are gzip so their original relative links remain byte-exact.
for source,targetname in [('docs/testing/artifacts/modular-workspace-2026-10-05/decisions.md','historical-decisions.md'),('src/lib/extensions/catalog/opencite.lock.json','historical-pins/opencite.lock.json'),('src/lib/extensions/catalog/literature-review.lock.json','historical-pins/literature-review.lock.json'),('docs/testing/modular-workspace-live-check.md','historical-pins/modular-workspace-live-check.md')]:
 raw=subprocess.check_output(['git','show','HEAD:'+source]);target=out/targetname;target.parent.mkdir(parents=True,exist_ok=True)
 if target.suffix=='.md':
  if target.exists():
   assert target.read_bytes()==raw;target.unlink()
  target=Path(str(target)+'.gz');target.write_bytes(gzip.compress(raw,mtime=0))
  index.append(dict(path=str(target.relative_to(root)),originalPath=source,rawSha256=hashlib.sha256(raw).hexdigest(),rawBytes=len(raw)))
 else:target.write_bytes(raw)
rulings=re.findall(r'^Ruling: R\d+:.*$',(scratch/'progress.md').read_text(),re.M)
assert [int(re.search(r'R(\d+):',s)[1]) for s in rulings]==list(range(1,80))
(root/'decisions.md').write_text('# Controller decisions R1–R79\n\nVerbatim chronological rulings from the authoritative progress ledger, including rationale and cost if wrong. Earlier proposals remain preserved when superseded. The historical R1–R59 ledger is also retained in final-fix/historical-decisions.md.gz.\n\n'+'\n\n'.join(rulings)+'\n')
(root/'raw-output-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(f'Preserved {len(index)} compressed raw records; 79 exact rulings.')
