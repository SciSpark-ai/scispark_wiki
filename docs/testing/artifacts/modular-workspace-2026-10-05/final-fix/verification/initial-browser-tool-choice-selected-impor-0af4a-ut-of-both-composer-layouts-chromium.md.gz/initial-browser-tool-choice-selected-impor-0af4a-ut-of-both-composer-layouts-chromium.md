# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tool-choice.spec.ts >> selected imported tools keep discussion-only scope out of both composer layouts
- Location: e2e/tool-choice.spec.ts:31:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByText('Saved papers only', { exact: true })
Expected: 0
Received: 1
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" with timeout 10000ms
  - waiting for getByText('Saved papers only', { exact: true })
    24 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - alert [ref=e2]: Sparky
  - generic [ref=e4]:
    - complementary [ref=e6]:
      - generic [ref=e7]:
        - button "Close sidebar" [ref=e8]
        - img "SciSpark" [ref=e12]
        - button "Switch to dark mode" [ref=e13]
      - navigation [ref=e16]:
        - generic [ref=e17]:
          - generic [ref=e18]: Discover
          - link "Home" [ref=e19] [cursor=pointer]:
            - /url: /
          - link "Sparky" [ref=e24] [cursor=pointer]:
            - /url: /chat
        - generic [ref=e28]:
          - generic [ref=e29]: Knowledge
          - link "Wiki" [ref=e30] [cursor=pointer]:
            - /url: /wiki
          - link "Graph" [ref=e34] [cursor=pointer]:
            - /url: /viz
          - link "Projects" [ref=e41] [cursor=pointer]:
            - /url: /projects
        - generic [ref=e45]:
          - generic [ref=e46]: Tools
          - link "Tools" [ref=e47] [cursor=pointer]:
            - /url: /tools
        - separator [ref=e51]
        - link "History" [ref=e52] [cursor=pointer]:
          - /url: /history
        - list "Recent chats" [ref=e57]:
          - listitem [ref=e58]:
            - link "MODULAR:scope Compare supplied evidence Oct 6, 1:38:07 AM" [ref=e59] [cursor=pointer]:
              - /url: /chat/chat_6c5a8dae-6757-45fe-87b9-a3fea7166165
              - generic [ref=e60]: MODULAR:scope Compare supplied evidence
              - time [ref=e61]: Oct 6, 1:38:07 AM
          - listitem [ref=e62]:
            - link "MODULAR:choice Compare the supplied research evidence Oct 6, 1:37:55 AM" [ref=e63] [cursor=pointer]:
              - /url: /chat/chat_3dc9c40b-f9da-46ae-aeb1-f2663ee1c89c
              - generic [ref=e64]: MODULAR:choice Compare the supplied research evidence
              - time [ref=e65]: Oct 6, 1:37:55 AM
      - generic [ref=e66]:
        - separator [ref=e67]
        - button "Profile menu" [ref=e69]:
          - generic [ref=e70]: A
          - generic [ref=e71]:
            - paragraph [ref=e72]: Ada
            - paragraph [ref=e73]: Local profile
    - main [ref=e74]:
      - generic [ref=e77]:
        - generic [ref=e78]:
          - heading "MODULAR:scope Compare supplied evidence" [level=1] [ref=e80]
          - navigation [ref=e81]:
            - link "History" [ref=e82] [cursor=pointer]:
              - /url: /history?tab=conversations
            - link "New chat" [ref=e86] [cursor=pointer]:
              - /url: /chat?new=1
        - generic "Conversation" [ref=e87]:
          - generic [ref=e88]:
            - generic [ref=e90]:
              - generic [ref=e91]: You
              - paragraph [ref=e92]: MODULAR:scope Compare supplied evidence
            - generic [ref=e97]:
              - generic [ref=e98]: Sparky
              - paragraph [ref=e100]: Your research run is saved.
              - generic [ref=e101]:
                - link "Open research run" [ref=e102] [cursor=pointer]:
                  - /url: /tools/runs/9c0d7299-1a6f-4817-bf1e-935adcd7a870
                - region "Research run" [ref=e103]:
                  - generic [ref=e104]:
                    - link "← Back" [ref=e105] [cursor=pointer]:
                      - /url: /chat/chat_6c5a8dae-6757-45fe-87b9-a3fea7166165
                    - link "All runs" [ref=e106] [cursor=pointer]:
                      - /url: /history?tab=runs
                    - link "Conversation" [ref=e107] [cursor=pointer]:
                      - /url: /chat/chat_6c5a8dae-6757-45fe-87b9-a3fea7166165
                  - generic [ref=e108]:
                    - heading "Evidence scope fixture" [level=1] [ref=e109]
                    - status [ref=e110]: Completed
                  - generic [ref=e111]:
                    - generic [ref=e112]: 3 calls used
                    - generic [ref=e113]: 0 commands used
                    - generic [ref=e114]: 10 seconds used
                    - generic [ref=e115]: $0.00 used
                  - generic [ref=e116]:
                    - heading "Synthetic evidence report" [level=1] [ref=e117]
                    - paragraph [ref=e118]: Method A improved on the supplied benchmark. Source.
                    - paragraph [ref=e119]:
                      - strong [ref=e120]: "Limitation:"
                      - text: invented evidence; no clinical validation.
                  - region "Saved artifacts" [ref=e121]:
                    - heading "Results" [level=2] [ref=e122]
                    - article [ref=e123]:
                      - heading "Synthetic source-linked report" [level=3] [ref=e124]
                      - generic [ref=e125]:
                        - button "Preview" [ref=e126]
                        - button "Download markdown" [ref=e127]
                      - group [ref=e128]:
                        - generic "Sources (1)" [ref=e129] [cursor=pointer]
                    - button "Add to wiki" [ref=e130]
                  - group [ref=e131]:
                    - generic "Diagnostics" [ref=e132] [cursor=pointer]
        - generic [ref=e133]:
          - generic [ref=e134]:
            - generic [ref=e135]:
              - text: Mode
              - combobox "Chat mode" [ref=e136]:
                - option "Discuss research" [selected]
                - option "Evidence scope fixture"
            - link "Tools" [ref=e137] [cursor=pointer]:
              - /url: /tools
            - generic [ref=e138] [cursor=pointer]:
              - generic [ref=e139]:
                - generic [ref=e140]: Saved papers only
                - generic [ref=e141]: Exclude notes, ideas, and other wiki pages.
              - switch "Saved papers only" [ref=e143]
          - generic [ref=e145]:
            - textbox "Message Sparky" [ref=e146]:
              - /placeholder: Ask about your research or the papers above…
            - button "Send" [disabled] [ref=e147]
          - paragraph [ref=e148]: Enter to send. Shift+Enter for a new line.
```

# Test source

```ts
  1  | import { expect, test } from "@playwright/test"
  2  | import { importTool, resetTools, providerRows, snapshot } from "./fixtures/modular"
  3  | 
  4  | test("ambiguous Sparky choice performs one classification and creates one chosen root", async ({ page, request }, info) => {
  5  |   await resetTools()
  6  |   await importTool(request, "Evidence comparison A")
  7  |   const { ref } = await importTool(request, "Evidence comparison B")
  8  |   await request.post("/api/profile", { data: { name: "Ada", role: "Researcher", fields: "Neuroscience", topics: "Speech", feedPrefs: "Methods" } })
  9  |   const before = (await (await request.get("/api/tools/runs")).json()).result.length
  10 |   await page.goto("/chat?new=1")
  11 |   await page.getByRole("textbox", { name: "Message Sparky" }).fill("MODULAR:choice Compare the supplied research evidence")
  12 |   await page.getByRole("button", { name: "Send", exact: true }).click()
  13 |   await expect(page.getByRole("button", { name: /^Evidence comparison B/ })).toBeVisible()
  14 |   expect((await (await request.get("/api/tools/runs")).json()).result).toHaveLength(before)
  15 |   await page.waitForURL(/\/chat\/chat_/); await expect(page.getByRole("button", { name: /^Evidence comparison B/ })).toBeVisible()
  16 |   await expect(page.getByText("Choose a tool for this request", { exact: true })).toHaveCount(1)
  17 |   await page.screenshot({ path: info.outputPath("ambiguousSparky.png"), fullPage: true })
  18 |   await page.reload()
  19 |   await page.getByRole("button", { name: /^Evidence comparison B/ }).click()
  20 |   await expect.poll(async () => (await (await request.get("/api/tools/runs")).json()).result.length).toBe(before + 1)
  21 |   const runs = (await (await request.get("/api/tools/runs")).json()).result
  22 |   const run = runs.at(-1)
  23 |   expect(run.tool).toEqual(ref)
  24 |   await expect.poll(async () => (await snapshot(request, run.id)).status, { timeout: 25000 }).toBe("completed")
  25 |   await page.reload()
  26 |   expect((await providerRows("choice")).filter(r => r.phase === "classification")).toHaveLength(1)
  27 |   expect((await providerRows("choice")).filter(r => r.phase === "review-synthesis")).toHaveLength(1)
  28 |   expect((await (await request.get("/api/tools/runs")).json()).result).toHaveLength(before + 1)
  29 | })
  30 | 
  31 | test("selected imported tools keep discussion-only scope out of both composer layouts",async({page,request},info)=>{
  32 |  await resetTools()
  33 |  const {ref}=await importTool(request,"Evidence scope fixture")
  34 |  await page.goto(`/chat?new=1&tool=${encodeURIComponent(JSON.stringify(ref))}`)
  35 |  await expect(page.getByRole("button",{name:"Evidence scope fixture",exact:true})).toBeVisible()
  36 |  await expect(page.getByText("Saved papers only",{exact:true})).toHaveCount(0)
  37 |  await page.getByRole("textbox",{name:"Message Sparky"}).fill("MODULAR:scope Compare supplied evidence")
  38 |  await page.getByRole("button",{name:"Send",exact:true}).click()
  39 |  await page.waitForURL(/\/chat\/chat_/)
> 40 |  await expect(page.getByText("Saved papers only",{exact:true})).toHaveCount(0)
     |                                                                 ^ Error: expect(locator).toHaveCount(expected) failed
  41 |  await page.setViewportSize({width:390,height:844})
  42 |  await page.screenshot({path:info.outputPath("selected-tool-composer-phone.png"),fullPage:true})
  43 |  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true)
  44 | })
  45 | 
```