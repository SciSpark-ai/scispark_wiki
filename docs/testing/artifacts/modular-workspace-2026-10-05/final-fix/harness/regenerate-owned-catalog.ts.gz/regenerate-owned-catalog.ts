import { ImportToolSchema, type AdapterProposal } from "/Users/tongshan/Documents/SciSpark_paper_manager/src/lib/extensions/import-contract"
import { snapshotDigest } from "/Users/tongshan/Documents/SciSpark_paper_manager/src/lib/extensions/store"
import type { ToolRef } from "/Users/tongshan/Documents/SciSpark_paper_manager/src/lib/extensions/contracts"
import { openciteCatalogEntry } from "/Users/tongshan/Documents/SciSpark_paper_manager/src/lib/extensions/catalog/opencite"
import openCiteLock from "/Users/tongshan/Documents/SciSpark_paper_manager/src/lib/extensions/catalog/opencite.lock.json"
import lock from "/Users/tongshan/Documents/SciSpark_paper_manager/src/lib/extensions/catalog/literature-review.lock.json"

const provenance = { source: "github" as const, locator: "https://github.com/neuromechanist/research-skills", revision: lock.researchSkillsRevision }
const outputKinds = ["markdown", "papers", "bibtex", "file"]
/** Same reviewed import identity calculation, verified against real inspect/review.
 * This is catalog data only, never an import, enabled binding or setup override. */
function snapshot(packageId: string, version: string, proposal: AdapterProposal, files: typeof lock.files) {
  const command = proposal.kind === "command" || proposal.setup.commands.length || proposal.setup.runtimes.length
  const tool = ImportToolSchema.parse({ manifest: { ref: { packageId, skillId: proposal.skillId, version, digest: "0".repeat(64) }, name: proposal.name, description: proposal.description, kind: proposal.kind, entrypoint: proposal.entrypoint, dependencies: proposal.dependencies, resources: proposal.resources, capabilities: proposal.capabilities, connections: proposal.connections, engines: proposal.engines, inputSchema: proposal.inputSchema, outputKinds: proposal.outputKinds, provenance }, proposal, inferred: false, reviewed: true, hostUnsupported: [], requirements: proposal.setup, files,
    compatibility: command ? { status: "unsupported", reasons: ["Command isolation and dependency setup are not available in package inspection"] } : { status: "ready", reasons: [] } })
  tool.manifest.ref.digest = snapshotDigest(tool)
  return tool
}
export function literatureReviewCatalogGraph() {
  const source = openciteCatalogEntry()
  const opencite = snapshot("neuromechanist.opencite", source.version, source.proposal, openCiteLock.files)
  const nodes: ReturnType<typeof snapshot>[] = []
  function node(name: string, dependencies: ToolRef[]) {
    const proposal: AdapterProposal = { skillId: `host/${name}/SKILL.md`, name: name === "lit-review" ? "Literature review" : name === "collection" ? "Strand collection" : name === "humanizer" ? "Prose refinement" : name === "manuscript-writing" ? "Manuscript writing" : "Paper review", description: "Literature synthesis with Semantic Scholar sources and writing support. Unavailable evidence stays explicit.", kind: "instructions", entrypoint: `host/${name}/protocol.md`, capabilities: name === "lit-review" ? ["literature-review"] : [], resources: lock.files.map(f => f.path), dependencies, dependencySlots: [], connections: [], engines: ["api", "codex", "claude-code"], inputSchema: name === "lit-review" ? { type: "object", properties: { question: { type: "string", minLength: 1, maxLength: 4000 } }, required: ["question"], additionalProperties: false } : { type: "object" }, outputKinds, setup: { commands: [], runtimes: [], unsupported: [], internalModelCalls: false } }
    const result = snapshot("neuromechanist.literature-review", lock.version, proposal, lock.files)
    nodes.push(result); return result.manifest.ref
  }
  const humanizer = node("humanizer", [])
  const writing = node("manuscript-writing", [humanizer])
  const review = node("paper-review", [opencite.manifest.ref, humanizer])
  const collection = node("collection", [opencite.manifest.ref])
  node("lit-review", [collection, writing, review, humanizer])

  return { opencite, nodes, root: nodes.at(-1)! }
}
