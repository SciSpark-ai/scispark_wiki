import {defineConfig} from "vitest/config"
import {resolve} from "node:path"
export default defineConfig({resolve:{alias:{"@":resolve("src")}},test:{include:[".superpowers/sdd/2026-10-05-modular-workspace/regenerate-owned-catalog.test.ts"],environment:"node"}})
