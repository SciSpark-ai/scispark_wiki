from pathlib import Path
import os, subprocess, json, time, hashlib, difflib, re, sys, tempfile
root = Path.cwd()
mode = sys.argv[1]
assert mode in ['regular', 'acceptance']
out = root / '.superpowers/sdd/2026-10-05-modular-workspace/verification/final-fix' / ('build-' + mode)
out.mkdir(parents=True, exist_ok=True)
dist = '.next-modular-final-fix-regular-v3' if mode == 'regular' else '.next-modular-final-fix-acceptance-v3'
files = ['tsconfig.json', 'next-env.d.ts']
before = {name: (root/name).read_bytes() for name in files}
for name, data in before.items(): (out/(name+'.before')).write_bytes(data)
fixture = Path(tempfile.mkdtemp(prefix='scispark-modular-final-fix-build-'))
env = dict(os.environ, SCISPARK_LIVE_GATE_DIST_DIR=dist, SCISPARK_VAULT=str(fixture/'vault'), SCISPARK_PROFILES_DIR=str(fixture/'profiles'), SCISPARK_SCHEDULER='off')
for name in ['SCISPARK_VAULT', 'SCISPARK_PROFILES_DIR']: Path(env[name]).mkdir(parents=True, exist_ok=True)
start = time.monotonic()
with (out/'build.log').open('w') as log:
    process = subprocess.run(['npm', 'run', 'build'], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
restored = {}
for name, previous in before.items():
    current = (root/name).read_bytes()
    (out/(name+'.after')).write_bytes(current)
    (out/(name+'.diff')).write_text(''.join(difflib.unified_diff(previous.decode().splitlines(True), current.decode().splitlines(True), fromfile=name+'.before', tofile=name+'.after')))
    if name == 'tsconfig.json':
        old, new = json.loads(previous), json.loads(current)
        extra = [x for x in new.get('include', []) if x not in old.get('include', [])]
        if any(x not in [dist+'/types/**/*.ts',dist+'/dev/types/**/*.ts'] for x in extra): raise RuntimeError('Unexpected tsconfig include changes; preserved for review')
        new['include'] = [x for x in new['include'] if x not in extra]
        if old != new: raise RuntimeError('Unexpected tsconfig changes; preserved for review')
    else:
        normalize = lambda data: re.sub(r'"\./[^"\n]+/types/(routes|root-params)\.d\.ts"', r'"./DIST/types/\1.d.ts"', data.decode())
        if normalize(current) != normalize(previous): raise RuntimeError('Unexpected next-env changes; preserved for review')
    if current != previous: (root/name).write_bytes(previous)
    restored[name] = {'sha256':hashlib.sha256(previous).hexdigest(), 'exactBytesRestored':(root/name).read_bytes()==previous}
result = {'command': 'npm run build', 'exitCode': process.returncode, 'seconds': round(time.monotonic()-start,2), 'dist':dist, 'vault': str(fixture/'vault'), 'config':restored}
(out/'build-result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2)); print((out/'build.log').read_text()[-2500:])
raise SystemExit(process.returncode)
