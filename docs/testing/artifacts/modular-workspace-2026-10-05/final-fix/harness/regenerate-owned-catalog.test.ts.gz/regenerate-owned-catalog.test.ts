import {it} from "vitest"
import {readFile,writeFile} from "node:fs/promises"
import {literatureReviewCatalogGraph} from "./regenerate-owned-catalog"
import open from "@/lib/extensions/catalog/opencite.lock.json"
it("regenerates owned catalog graph identities",async()=>{
 const path="src/lib/extensions/catalog/literature-review.lock.json",lock=JSON.parse(await readFile(path,"utf8"))
 const {opencite,nodes}=literatureReviewCatalogGraph()
 lock.graph=[opencite,...nodes].map(t=>({ref:t.manifest.ref,dependencies:t.manifest.dependencies}))
 lock.opencite.bundleDigest=open.bundleDigest
 await writeFile(path,JSON.stringify(lock,null,2)+"\n")
})
