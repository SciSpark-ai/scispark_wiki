import { defineConfig } from 'vitest/config'
import path from 'node:path'
export default defineConfig({ test: { include: ['.superpowers/sdd/2026-10-05-modular-workspace/final-review-repro.test.ts'], environment: 'node' }, resolve: { alias: { '@': path.resolve(process.cwd(), 'src') } } })
