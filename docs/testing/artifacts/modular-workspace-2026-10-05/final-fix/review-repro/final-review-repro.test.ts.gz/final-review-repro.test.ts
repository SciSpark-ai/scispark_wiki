import { afterEach, expect, it, vi } from 'vitest'
import { randomUUID } from 'node:crypto'
import { mkdtemp, mkdir, writeFile, rm, realpath } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import * as intent from '@/lib/extensions/intent'
import * as library from '@/lib/extensions/library'
import * as classification from '@/lib/extensions/classification-attempt'
import { literatureReviewCatalogGraph } from '@/lib/extensions/catalog/literature-review'
import { openciteCatalogEntry, OpenCiteInputSchema } from '@/lib/extensions/catalog/opencite'
import { validateInputSchema, inspectPackage, reviewImport, commitImport } from '@/lib/extensions/inspect'
import { acquirePackage } from '@/lib/extensions/acquire'
import { NATIVE_TOOL_MANIFESTS } from '@/lib/extensions/native-catalog'
import { NodeFsVaultStorage } from '@/lib/vault/node-fs-storage'
import { askChat } from '@/lib/chat/orchestrator'
import { grantDiscovery } from '@/lib/extensions/discovery'
import { toolKey } from '@/lib/extensions/contracts'
import { applyToolAction, checkToolUpdate, applyToolUpdate, rollbackTool } from '@/lib/extensions/versions'
import { readProfileTools } from '@/lib/extensions/store'
const roots: string[] = []
afterEach(async () => { vi.restoreAllMocks(); await Promise.all(roots.splice(0).map(root => rm(root,{recursive:true,force:true}))) })
async function fixture() {
  const root = await realpath(await mkdtemp(join(tmpdir(),'scispark-final-review-'))); roots.push(root)
  const vaultPath=join(root,'vault'), runtimeRoot=join(root,'runtime'); await mkdir(vaultPath); await mkdir(runtimeRoot)
  return {root,ctx:{profileId:randomUUID(),vaultId:'a'.repeat(64),vaultPath,runtimeRoot,storage:new NodeFsVaultStorage(vaultPath)}}
}
const request = () => ({sessionId:'chat_fixture',operationId:randomUUID(),question:'Review auditory attention decoding methods',contextRefs:[]})
it('F1: the actual Literature review accepts its normal public chat envelope', () => {
  const root=literatureReviewCatalogGraph().root
  expect(validateInputSchema(root.manifest.inputSchema).safeParse(intent.toolRunInput(request(),root.manifest.ref)).success).toBe(true)
})
it('F1: the actual OpenCite accepts its normal public chat envelope', () => {
  const entry=openciteCatalogEntry(), ref={packageId:'neuromechanist.opencite',skillId:entry.proposal.skillId,version:entry.version,digest:'a'.repeat(64)}
  expect(OpenCiteInputSchema.safeParse(intent.toolRunInput(request(),ref)).success).toBe(true)
})
it('F2: naming an enabled unavailable tool must not classify only alternatives', async () => {
  const {ctx}=await fixture(), base=NATIVE_TOOL_MANIFESTS.find(t=>t.ref.skillId==='deep-review')!
  const tools=[{...base,name:'Evidence Atlas',ref:{...base.ref,packageId:'fixture.import'},enabled:true,installed:true,pinned:false,readiness:{status:'needs-setup' as const,reasons:['Restore connection']},connectionRequirements:[]},{...base,enabled:true,installed:true,pinned:false,readiness:{status:'ready' as const,reasons:[]},connectionRequirements:[]}]
  vi.spyOn(library,'listToolLibrary').mockResolvedValue({tools,catalog:[],discoveryDismissed:false})
  const classify=vi.spyOn(classification,'classifyToolIntent').mockResolvedValue({kind:'tools',toolIds:[0]})
  const result=await intent.resolveToolIntent(ctx,{...request(),question:'Use Evidence Atlas to review speech'})
  console.log('F2 actual resolution:',result,'classifier candidates:',classify.mock.calls[0]?.[2].map(t=>t.name))
  expect(classify).not.toHaveBeenCalled()
})
it('F3: the visible Saved papers only toggle must not discard an explicit tool selection', async () => {
  const {ctx}=await fixture(), tool=NATIVE_TOOL_MANIFESTS.find(t=>t.ref.skillId==='idea-spark')!.ref
  const resolve=vi.spyOn(intent,'resolveToolIntent').mockResolvedValue({kind:'clarify',question:'Selected tool retained'})
  const result=await askChat(ctx.storage,{workflowContext:ctx,input:{sessionId:'chat_toggle',operationId:randomUUID(),question:'Generate research ideas',mode:'chat',readSourcesOnly:true,explicitTool:tool}})
  console.log('F3 actual result:',result.message.content)
  expect(resolve).toHaveBeenCalled()
})
it('F4: rollback retains the latest explicitly saved settings for the selected version', async () => {
  const {root,ctx}=await fixture(), source=join(root,'source');await mkdir(source)
  const skill=(body:string)=>`---\nname: Research\nscispark:\n  engines: [api, codex, claude-code]\n---\n${body}`
  await writeFile(join(source,'SKILL.md'),skill('One'))
  const p=await inspectPackage(ctx,await acquirePackage(ctx,{kind:'local-folder',path:source})),r=await reviewImport(ctx,p.id,p.tools.map(t=>t.proposal))
  const [v1]=await commitImport(ctx,r.id,[r.tools[0].manifest.ref]),key=toolKey(v1)
  const setCap=(costUsd:number)=>applyToolAction(ctx,key,{action:'binding',operationId:randomUUID(),patch:{defaultAllowance:{costUsd}}})
  await setCap(5)
  await writeFile(join(source,'SKILL.md'),skill('Two'))
  const grant=await grantDiscovery(ctx,[{agent:'custom',layout:'package',path:source}])
  const update=await checkToolUpdate(ctx,key,{force:true,grantId:grant.id})
  const v2=await applyToolUpdate(ctx,key,update!.id,randomUUID())
  await rollbackTool(ctx,key,v1.digest,randomUUID()); await setCap(1)
  await rollbackTool(ctx,key,v2.digest,randomUUID()); await rollbackTool(ctx,key,v1.digest,randomUUID())
  const actual=(await readProfileTools(ctx))!.overrides.find(o=>o.toolKey===key)!.defaultAllowance!.costUsd
  console.log('F4 after saving $1 on v1, switching away and restoring v1:',actual)
  expect(actual).toBe(1)
})

it('F1: an ordinary SKILL import accepts the public human request', async () => {
  const {root,ctx}=await fixture(), source=join(root,'ordinary');await mkdir(source)
  await writeFile(join(source,'SKILL.md'),'---\nname: Plain reviewer\ndescription: Reviews the requested topic\n---\nReview the human request and cite sources.')
  const p=await inspectPackage(ctx,await acquirePackage(ctx,{kind:'local-folder',path:source}))
  const tool=p.tools[0]
  console.log('F1 ordinary proposal:',tool.proposal.inputSchema)
  expect(validateInputSchema(tool.manifest.inputSchema).safeParse(intent.toolRunInput(request(),tool.manifest.ref)).success).toBe(true)
})
